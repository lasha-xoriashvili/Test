const axios = require('axios');
const TelegramBot = require('node-telegram-bot-api');


const token = '8514622029:AAGTGy-d0L5y6Ona5a7zTilSF4Ge6x58Vbc';
const bot = new TelegramBot(token,{polling: true});
const url = 'https://rowix.com/currencies.php';

bot.onText(/\/start/,(msg)=>{
    const name = msg.from.first_name;
    const opts = {reply_markup:{
        inline_keyboard:[[
            {text: 'USD',callback_data:'USD'},
            {text: 'EUR',callback_data:'EUR'}
        ],
        [
            {text:'GBP',callback_data:'GBP'},
            {text:'All',callback_data:'ALL'}
        ]]
    }}
    bot.sendMessage(msg.chat.id,
    `Hello ${name}! Welcome to the Currency Bot. Chose your desired currency:`,opts);
});

bot.on('callback_query',async (callbackQuery)=>{
    const chatId = callbackQuery.message.chat.id;
    const choice = callbackQuery.data;

    try{
        const response = await axios.get(url);
        const data = response.data;
        if(choice === 'ALL'){
            let allResult = ``;
            await data.forEach(item =>{
                allResult += `${item.symbol}${item.name}(${item.code}):${item.rate}\n`;
            });
            bot.sendMessage(chatId,allResult);
        }
        else{
            const selected = data.find(item=> item.code === choice);
            if(selected){
                bot.sendMessage(chatId,`${selected.symbol}${selected.name}(${selected.code}):${selected.rate}\n`)
            }
        }
    }
    catch(e){

        bot.sendMessage(chatId,`error occurred ${e}`);

    }
})

bot.onText('/USD',async (msg)=>{
    const chatId = msg.chat.id;

    try{
        const response = await axios.get(url);
        const data = response.data;
        const selected = data.find(item=> item.code === 'USD');
        if(selected){
            bot.sendMessage(chatId,`${selected.symbol}${selected.name}(${selected.code}):${selected.rate}\n`)
        }
    }
    catch{
        bot.sendMessage(chatId,`error occurred ${e}`);
    }
});
bot.onText('/EUR',async (msg)=>{
    const chatId = msg.chat.id;

    try{
        const response = await axios.get(url);
        const data = response.data;
        const selected = data.find(item=> item.code === 'EUR');
        if(selected){
            bot.sendMessage(chatId,`${selected.symbol}${selected.name}(${selected.code}):${selected.rate}\n`)
        }
    }
    catch{
        bot.sendMessage(chatId,`error occurred ${e}`);
    }
});
bot.onText('/GBP',async (msg)=>{
    const chatId = msg.chat.id;

    try{
        const response = await axios.get(url);
        const data = response.data;
        const selected = data.find(item=> item.code === 'GBP');
        if(selected){
            bot.sendMessage(chatId,`${selected.symbol}${selected.name}(${selected.code}):${selected.rate}\n`)
        }
    }
    catch{
        bot.sendMessage(chatId,`error occurred ${e}`);
    }
});

bot.onText('/ALL',async (msg)=>{
    const chatId = msg.chat.id;

    try{
        const response = await axios.get(url);
        const data = response.data;
        let allResult = ``;
        await data.forEach(item =>{
            allResult += `${item.symbol}${item.name}(${item.code}):${item.rate}\n`;
        });
        bot.sendMessage(chatId,allResult);
    }
    catch{
        bot.sendMessage(chatId,`error occurred ${e}`);
    }
})


console.log('bot is starting');